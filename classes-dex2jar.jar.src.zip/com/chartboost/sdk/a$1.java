package com.chartboost.sdk;

import com.chartboost.sdk.impl.a;
import com.chartboost.sdk.impl.n;

class a$1 implements n.a {
  final a a;
  
  a$1(a parama) {}
  
  public void a(a parama) {
    (a.a(this.a)).a.post(new a$b(this.a, parama, false));
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\chartboost\sdk\a$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package com.chartboost.sdk;

import com.chartboost.sdk.impl.k;
import org.json.JSONObject;

class Chartboost$2$1 implements k.a {
  final Chartboost$2 a;
  
  private final String b;
  
  Chartboost$2$1(Chartboost$2 paramChartboost$2, String paramString) {}
  
  public void a(JSONObject paramJSONObject) {
    Chartboost.a(Chartboost.sharedChartboost(), paramJSONObject, this.b);
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\chartboost\sdk\Chartboost$2$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
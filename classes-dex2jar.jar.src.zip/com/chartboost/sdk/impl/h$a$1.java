package com.chartboost.sdk.impl;

import android.view.View;

class h$a$1 implements View.OnClickListener {
  final h$a a;
  
  h$a$1(h$a paramh$a) {}
  
  public void onClick(View paramView) {
    if ((h$a.b(this.a)).a != null)
      (h$a.b(this.a)).a.a(); 
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\chartboost\sdk\impl\h$a$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
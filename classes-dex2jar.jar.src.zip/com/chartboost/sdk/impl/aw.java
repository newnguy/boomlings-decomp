package com.chartboost.sdk.impl;

import java.io.Serializable;

public class aw implements Serializable {
  public boolean equals(Object paramObject) {
    return paramObject instanceof aw;
  }
  
  public int hashCode() {
    return 0;
  }
  
  public String toString() {
    return "MaxKey";
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\chartboost\sdk\impl\aw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
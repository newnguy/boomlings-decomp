package com.chartboost.sdk.impl;

final class ag$1 extends ThreadLocal {
  protected ai a() {
    return new al();
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\chartboost\sdk\impl\ag$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
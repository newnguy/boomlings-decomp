package com.chartboost.sdk.impl;

final class aq$1 extends bh {
  aq$1(int paramInt) {
    super(paramInt);
  }
  
  protected byte[] a() {
    return new byte[16384];
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\chartboost\sdk\impl\aq$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
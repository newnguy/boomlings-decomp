package com.chartboost.sdk.impl;

import android.view.MotionEvent;
import android.view.View;

class s$2 implements View.OnTouchListener {
  final s a;
  
  s$2(s params) {}
  
  public boolean onTouch(View paramView, MotionEvent paramMotionEvent) {
    return true;
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\chartboost\sdk\impl\s$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
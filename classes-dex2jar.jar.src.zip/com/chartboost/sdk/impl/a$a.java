package com.chartboost.sdk.impl;

import org.json.JSONObject;

public interface a$a {
  void a(a parama);
  
  void a(a parama, String paramString, JSONObject paramJSONObject);
  
  void b(a parama);
  
  void c(a parama);
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\chartboost\sdk\impl\a$a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
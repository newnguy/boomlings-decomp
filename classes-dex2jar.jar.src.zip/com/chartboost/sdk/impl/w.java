package com.chartboost.sdk.impl;

public class w extends am implements y {
  public w() {}
  
  public w(String paramString, Object paramObject) {
    super(paramString, paramObject);
  }
  
  public String toString() {
    return ac.a(this);
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\chartboost\sdk\impl\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package com.chartboost.sdk.impl;

import java.util.HashMap;
import java.util.Map;

class bf$b extends bf {
  bf$b(Map paramMap, ba$h$a paramba$h$a) {
    super(paramMap, paramba$h$a);
  }
  
  public Map a(Map<?, ?> paramMap) {
    return new HashMap<Object, Object>(paramMap);
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\chartboost\sdk\impl\bf$b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
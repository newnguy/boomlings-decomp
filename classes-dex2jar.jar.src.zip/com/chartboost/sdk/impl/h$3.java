package com.chartboost.sdk.impl;

import android.os.Bundle;
import com.chartboost.sdk.Libraries.a;
import com.chartboost.sdk.Libraries.e;

class h$3 implements e.b {
  final h a;
  
  h$3(h paramh) {}
  
  public void a(a.a parama, Bundle paramBundle) {
    h.c(this.a, parama);
    h.a(this.a, parama);
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\chartboost\sdk\impl\h$3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package com.chartboost.sdk.impl;

public class ae$a extends RuntimeException {
  final String a;
  
  ae$a(String paramString) {
    super(paramString);
    this.a = paramString;
  }
  
  public String toString() {
    return this.a;
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\chartboost\sdk\impl\ae$a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package com.chartboost.sdk.impl;

import java.util.UUID;

class ad$r extends ad$c {
  ad$r(af paramaf) {
    super(paramaf);
  }
  
  public void a(Object paramObject, StringBuilder paramStringBuilder) {
    UUID uUID = (UUID)paramObject;
    paramObject = new w();
    paramObject.a("$uuid", uUID.toString());
    this.a.a(paramObject, paramStringBuilder);
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\chartboost\sdk\impl\ad$r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
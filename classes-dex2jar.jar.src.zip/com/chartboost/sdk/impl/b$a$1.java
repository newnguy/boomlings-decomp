package com.chartboost.sdk.impl;

import android.view.View;

class b$a$1 implements View.OnClickListener {
  final b$a a;
  
  b$a$1(b$a paramb$a) {}
  
  public void onClick(View paramView) {
    if ((b$a.a(this.a)).a != null)
      (b$a.a(this.a)).a.a(); 
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\chartboost\sdk\impl\b$a$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
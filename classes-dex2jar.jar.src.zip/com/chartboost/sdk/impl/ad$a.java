package com.chartboost.sdk.impl;

class ad$a extends ad$c {
  ad$a(af paramaf) {
    super(paramaf);
  }
  
  public void a(Object paramObject, StringBuilder paramStringBuilder) {
    au au = (au)paramObject;
    paramObject = new w();
    paramObject.a("$code", au.a());
    this.a.a(paramObject, paramStringBuilder);
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\chartboost\sdk\impl\ad$a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package com.chartboost.sdk;

import com.chartboost.sdk.impl.m;

class Chartboost$1 implements m.a {
  final Chartboost a;
  
  Chartboost$1(Chartboost paramChartboost) {}
  
  public void a(String paramString) {
    a a1 = Chartboost.a(this.a);
    if (a1 != null && a1.a())
      a1.a(true); 
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\chartboost\sdk\Chartboost$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package com.flurry.android;

import android.content.Context;
import java.util.List;

final class f extends an {
  private Context a;
  
  private bo b;
  
  f(bo parambo, Context paramContext) {}
  
  public final void a() {
    int i = ac.c(this.a);
    int j = ac.d(this.a);
    List list = this.b.a("", i, j, true, (FlurryAdSize)null);
    this.b.b(list);
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\flurry\android\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
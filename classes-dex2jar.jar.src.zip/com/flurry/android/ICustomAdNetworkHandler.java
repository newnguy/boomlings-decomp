package com.flurry.android;

import android.content.Context;

public interface ICustomAdNetworkHandler {
  AdNetworkView getAdFromNetwork(Context paramContext, AdCreative paramAdCreative, String paramString);
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\flurry\android\ICustomAdNetworkHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package com.flurry.android;

final class u extends an {
  private a a;
  
  u(a parama) {}
  
  public final void a() {
    FlurryAgent.b(this.a.b, this.a.a);
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\flurry\androi\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
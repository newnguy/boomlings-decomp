package com.flurry.android;

import android.content.Context;
import java.util.Map;

final class bj {
  final String a;
  
  final Map b;
  
  final Context c;
  
  final AdUnit d;
  
  final bl e;
  
  final int f;
  
  bj(String paramString, Map paramMap, Context paramContext, AdUnit paramAdUnit, bl parambl, int paramInt) {
    this.a = paramString;
    this.b = paramMap;
    this.c = paramContext;
    this.d = paramAdUnit;
    this.e = parambl;
    this.f = paramInt;
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\flurry\android\bj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
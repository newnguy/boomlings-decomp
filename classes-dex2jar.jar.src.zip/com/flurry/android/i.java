package com.flurry.android;

final class i extends an {
  private bo a;
  
  i(bo parambo) {}
  
  public final void a() {
    this.a.e("/postAdLog.do");
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\flurry\android\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
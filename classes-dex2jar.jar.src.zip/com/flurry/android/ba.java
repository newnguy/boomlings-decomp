package com.flurry.android;

import android.content.Context;
import android.view.ViewGroup;

final class ba extends aj {
  ba() {
    super(null);
  }
  
  final void a(Context paramContext, ViewGroup paramViewGroup) {}
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\flurry\android\ba.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
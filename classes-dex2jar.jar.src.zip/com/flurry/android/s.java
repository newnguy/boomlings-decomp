package com.flurry.android;

import android.content.DialogInterface;

final class s implements DialogInterface.OnShowListener {
  private bf a;
  
  s(bf parambf) {}
  
  public final void onShow(DialogInterface paramDialogInterface) {
    if (ap.l(this.a.a) != null)
      ap.l(this.a.a).hide(); 
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\flurry\android\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
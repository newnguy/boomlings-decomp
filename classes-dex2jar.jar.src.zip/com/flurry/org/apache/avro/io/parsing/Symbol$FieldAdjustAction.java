package com.flurry.org.apache.avro.io.parsing;

public class Symbol$FieldAdjustAction extends Symbol$ImplicitAction {
  public final String fname;
  
  public final int rindex;
  
  public Symbol$FieldAdjustAction(int paramInt, String paramString) {
    super((Symbol$1)null);
    this.rindex = paramInt;
    this.fname = paramString;
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\flurry\org\apache\avro\io\parsing\Symbol$FieldAdjustAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package com.flurry.org.apache.avro.io.parsing;

public class Symbol$IntCheckAction extends Symbol {
  public final int size;
  
  public Symbol$IntCheckAction(int paramInt) {
    super(Symbol$Kind.EXPLICIT_ACTION);
    this.size = paramInt;
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\flurry\org\apache\avro\io\parsing\Symbol$IntCheckAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
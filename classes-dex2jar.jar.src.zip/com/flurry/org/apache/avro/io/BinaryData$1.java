package com.flurry.org.apache.avro.io;

final class BinaryData$1 extends ThreadLocal {
  protected BinaryData$Decoders initialValue() {
    return new BinaryData$Decoders();
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\flurry\org\apache\avro\io\BinaryData$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
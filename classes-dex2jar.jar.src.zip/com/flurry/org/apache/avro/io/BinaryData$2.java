package com.flurry.org.apache.avro.io;

final class BinaryData$2 extends ThreadLocal {
  protected BinaryData$HashData initialValue() {
    return new BinaryData$HashData();
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\flurry\org\apache\avro\io\BinaryData$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
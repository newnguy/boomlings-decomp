package com.b.a;

public final class q {}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\b\a\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
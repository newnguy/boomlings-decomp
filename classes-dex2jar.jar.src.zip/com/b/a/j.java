package com.b.a;

import android.os.Bundle;

public interface j {
  void a(Bundle paramBundle);
  
  void a(m paramm);
  
  void a(Error paramError);
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\b\a\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
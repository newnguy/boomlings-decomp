package com.b.a;

import android.view.View;

class o implements View.OnClickListener {
  final n a;
  
  o(n paramn) {}
  
  public void onClick(View paramView) {
    n.a(this.a).onCancel();
    this.a.dismiss();
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\b\a\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package com.b.a;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;

public interface d {
  void onComplete(String paramString, Object paramObject);
  
  void onFacebookError(m paramm, Object paramObject);
  
  void onFileNotFoundException(FileNotFoundException paramFileNotFoundException, Object paramObject);
  
  void onIOException(IOException paramIOException, Object paramObject);
  
  void onMalformedURLException(MalformedURLException paramMalformedURLException, Object paramObject);
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\b\a\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package com.b.a;

import android.os.Bundle;

public interface i {
  void onCancel();
  
  void onComplete(Bundle paramBundle);
  
  void onError(e parame);
  
  void onFacebookError(m paramm);
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\classes-dex2jar.jar!\com\b\a\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
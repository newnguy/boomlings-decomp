package com.flurry.android;

import java.util.Map;

final class y {
  final String a;
  
  final Map b;
  
  final bj c;
  
  y(String paramString, Map paramMap, bj parambj) {
    this.a = paramString;
    this.b = paramMap;
    this.c = parambj;
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\boomlings-1-20-dex2jar.jar!\com\flurry\android\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package com.flurry.android;

import android.os.Build;

public final class VersionUtil {
  public static final int SDK_INT = Integer.parseInt(Build.VERSION.SDK);
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\boomlings-1-20-dex2jar.jar!\com\flurry\android\VersionUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
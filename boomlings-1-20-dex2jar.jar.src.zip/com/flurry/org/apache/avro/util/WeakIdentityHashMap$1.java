package com.flurry.org.apache.avro.util;

import java.util.Map;

class WeakIdentityHashMap$1 implements Map.Entry {
  final WeakIdentityHashMap this$0;
  
  final Object val$key;
  
  final Object val$value;
  
  public Object getKey() {
    return key;
  }
  
  public Object getValue() {
    return value;
  }
  
  public Object setValue(Object paramObject) {
    throw new UnsupportedOperationException();
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\boomlings-1-20-dex2jar.jar!\com\flurry\org\apache\avr\\util\WeakIdentityHashMap$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
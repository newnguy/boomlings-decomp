package com.flurry.org.apache.avro.file;

public class DataFileWriter$AppendWriteException extends RuntimeException {
  public DataFileWriter$AppendWriteException(Exception paramException) {
    super(paramException);
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\boomlings-1-20-dex2jar.jar!\com\flurry\org\apache\avro\file\DataFileWriter$AppendWriteException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
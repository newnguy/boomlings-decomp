package com.flurry.org.apache.avro.file;

class NullCodec$Option extends CodecFactory {
  protected Codec createInstance() {
    return NullCodec.access$000();
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\boomlings-1-20-dex2jar.jar!\com\flurry\org\apache\avro\file\NullCodec$Option.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
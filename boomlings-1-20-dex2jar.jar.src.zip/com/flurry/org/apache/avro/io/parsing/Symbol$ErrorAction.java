package com.flurry.org.apache.avro.io.parsing;

public class Symbol$ErrorAction extends Symbol$ImplicitAction {
  public final String msg;
  
  private Symbol$ErrorAction(String paramString) {
    super((Symbol$1)null);
    this.msg = paramString;
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\boomlings-1-20-dex2jar.jar!\com\flurry\org\apache\avro\io\parsing\Symbol$ErrorAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
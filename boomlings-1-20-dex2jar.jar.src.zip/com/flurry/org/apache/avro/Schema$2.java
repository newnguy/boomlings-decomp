package com.flurry.org.apache.avro;

import java.util.IdentityHashMap;
import java.util.Map;

final class Schema$2 extends ThreadLocal {
  protected Map initialValue() {
    return new IdentityHashMap<Object, Object>();
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\boomlings-1-20-dex2jar.jar!\com\flurry\org\apache\avro\Schema$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
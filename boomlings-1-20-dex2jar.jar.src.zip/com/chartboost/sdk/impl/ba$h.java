package com.chartboost.sdk.impl;

import java.util.Collection;
import java.util.Set;

public abstract class ba$h {
  abstract Set a();
  
  abstract Set b();
  
  abstract Collection c();
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\boomlings-1-20-dex2jar.jar!\com\chartboost\sdk\impl\ba$h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package com.chartboost.sdk.impl;

import com.chartboost.sdk.b;

class a$1 implements b.a {
  final a a;
  
  private final a b;
  
  a$1(a parama1, a parama2) {}
  
  public void a() {
    if (this.b.g != null)
      this.b.g.a(this.b); 
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\boomlings-1-20-dex2jar.jar!\com\chartboost\sdk\impl\a$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
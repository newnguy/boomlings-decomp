package com.chartboost.sdk.impl;

import android.os.Bundle;
import com.chartboost.sdk.Libraries.a;
import com.chartboost.sdk.Libraries.e;

class b$4 implements e.b {
  final b a;
  
  b$4(b paramb) {}
  
  public void a(a.a parama, Bundle paramBundle) {
    this.a.j = parama;
    b.a(this.a, parama);
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\boomlings-1-20-dex2jar.jar!\com\chartboost\sdk\impl\b$4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
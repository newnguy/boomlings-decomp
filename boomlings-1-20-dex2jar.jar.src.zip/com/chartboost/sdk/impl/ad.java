package com.chartboost.sdk.impl;

import java.util.Date;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

public class ad {
  public static af a() {
    ab ab = b();
    ab.a(Date.class, new ad$i(ab));
    ab.a(as.class, new ad$g(ab));
    ab.a(at.class, new ad$h(null));
    ab.a(byte[].class, new ad$h(null));
    return ab;
  }
  
  static ab b() {
    ab ab = new ab();
    ab.a(Object[].class, new ad$m(ab));
    ab.a(Boolean.class, new ad$q(null));
    ab.a(au.class, new ad$a(ab));
    ab.a(av.class, new ad$b(ab));
    ab.a(y.class, new ad$d(ab));
    ab.a(z.class, new ad$e(ab));
    ab.a(Iterable.class, new ad$f(ab));
    ab.a(Map.class, new ad$j(ab));
    ab.a(aw.class, new ad$k(ab));
    ab.a(ax.class, new ad$l(ab));
    ab.a(Number.class, new ad$q(null));
    ab.a(ay.class, new ad$n(ab));
    ab.a(Pattern.class, new ad$o(ab));
    ab.a(String.class, new ad$p(null));
    ab.a(UUID.class, new ad$r(ab));
    return ab;
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\boomlings-1-20-dex2jar.jar!\com\chartboost\sdk\impl\ad.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
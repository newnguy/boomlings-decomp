package com.chartboost.sdk.impl;

abstract class ad$c extends aa {
  protected final af a;
  
  ad$c(af paramaf) {
    this.a = paramaf;
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\boomlings-1-20-dex2jar.jar!\com\chartboost\sdk\impl\ad$c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
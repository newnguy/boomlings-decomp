package com.chartboost.sdk.impl;

import java.util.regex.Pattern;

public class ae {
  private static Pattern a = Pattern.compile("\\s+", 40);
  
  public static void a(int paramInt1, int paramInt2) {
    if (paramInt1 != paramInt2)
      throw new ae$a("" + paramInt1 + " != " + paramInt2); 
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\boomlings-1-20-dex2jar.jar!\com\chartboost\sdk\impl\ae.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package com.chartboost.sdk.impl;

import java.io.Serializable;
import org.json.JSONObject;

public class j$b implements Serializable {
  public k a;
  
  public JSONObject b;
  
  public Integer c;
  
  final j d;
  
  public j$b(j paramj, k paramk, JSONObject paramJSONObject) {
    this.a = paramk;
    this.b = paramJSONObject;
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\boomlings-1-20-dex2jar.jar!\com\chartboost\sdk\impl\j$b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
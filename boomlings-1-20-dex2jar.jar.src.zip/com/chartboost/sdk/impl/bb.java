package com.chartboost.sdk.impl;

public class bb {
  public static Object a(String paramString, Object paramObject) {
    if (paramObject == null)
      throw new bb$a(paramString); 
    return paramObject;
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\boomlings-1-20-dex2jar.jar!\com\chartboost\sdk\impl\bb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
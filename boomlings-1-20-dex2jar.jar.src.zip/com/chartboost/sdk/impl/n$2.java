package com.chartboost.sdk.impl;

import android.view.animation.Animation;

class n$2 implements Animation.AnimationListener {
  private final n$a a;
  
  private final a b;
  
  n$2(n$a paramn$a, a parama) {}
  
  public void onAnimationEnd(Animation paramAnimation) {
    if (this.a != null)
      this.a.a(this.b); 
  }
  
  public void onAnimationRepeat(Animation paramAnimation) {}
  
  public void onAnimationStart(Animation paramAnimation) {}
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\boomlings-1-20-dex2jar.jar!\com\chartboost\sdk\impl\n$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
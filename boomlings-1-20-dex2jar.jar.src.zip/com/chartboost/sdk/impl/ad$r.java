package com.chartboost.sdk.impl;

class ad$r extends ad$c {
  ad$r(af paramaf) {
    super(paramaf);
  }
  
  public void a(Object paramObject, StringBuilder paramStringBuilder) {
    paramObject = paramObject;
    w w = new w();
    w.a("$uuid", paramObject.toString());
    this.a.a(w, paramStringBuilder);
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\boomlings-1-20-dex2jar.jar!\com\chartboost\sdk\impl\ad$r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package com.chartboost.sdk.impl;

class ad$e extends ad$c {
  ad$e(af paramaf) {
    super(paramaf);
  }
  
  public void a(Object paramObject, StringBuilder paramStringBuilder) {
    paramObject = paramObject;
    w w = new w();
    w.a("$ref", paramObject.b());
    w.a("$id", paramObject.a());
    this.a.a(w, paramStringBuilder);
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\boomlings-1-20-dex2jar.jar!\com\chartboost\sdk\impl\ad$e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
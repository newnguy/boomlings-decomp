package com.chartboost.sdk.impl;

import com.chartboost.sdk.b;

class a$2 implements b.a {
  final a a;
  
  private final a b;
  
  a$2(a parama1, a parama2) {}
  
  public void a() {
    if (this.b.g != null)
      this.b.g.b(this.b); 
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\boomlings-1-20-dex2jar.jar!\com\chartboost\sdk\impl\a$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package com.chartboost.sdk.impl;

import java.util.HashMap;
import java.util.Map;

public class bf$a {
  private ba$h$a a = ba$h$a.a;
  
  private final Map b = new HashMap<Object, Object>();
  
  public bf a() {
    return new bf$b(this.b, this.a);
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\boomlings-1-20-dex2jar.jar!\com\chartboost\sdk\impl\bf$a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
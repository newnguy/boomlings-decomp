package com.chartboost.sdk;

import com.chartboost.sdk.impl.a;

class a$b implements Runnable {
  final a a;
  
  private a b;
  
  private boolean c;
  
  public a$b(a parama, a parama1, boolean paramBoolean) {
    this.b = parama1;
    this.c = paramBoolean;
  }
  
  public void run() {
    if (this.b.c == a.b.d) {
      this.b.c = a.b.a;
      this.a.b(this.b, this.c);
    } 
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\boomlings-1-20-dex2jar.jar!\com\chartboost\sdk\a$b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
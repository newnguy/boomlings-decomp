package com.chartboost.sdk;

import com.chartboost.sdk.impl.a;
import com.chartboost.sdk.impl.k;
import org.json.JSONObject;

class Chartboost$5 implements k.a {
  final Chartboost a;
  
  private final boolean b;
  
  private final String c;
  
  Chartboost$5(Chartboost paramChartboost, boolean paramBoolean, String paramString) {}
  
  public void a(JSONObject paramJSONObject) {
    Chartboost.a(Chartboost.sharedChartboost(), paramJSONObject, a.c.b, this.b, this.c);
  }
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\boomlings-1-20-dex2jar.jar!\com\chartboost\sdk\Chartboost$5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
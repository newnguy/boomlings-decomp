package com.b.a;

public final class r {
  public static final int close = 2130837504;
  
  public static final int facebook_icon = 2130837505;
}


/* Location:              C:\Users\walle\Downloads\boomlings-1-20 (2)\boomlings-1-20-dex2jar.jar!\com\b\a\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */